#!/usr/bin/env python3
"""Safe Polymarket scanner prototype.

Scans open markets from Polymarket Gamma API, scores short-term tradability,
and prints the top candidates. This version is intentionally read-only: no
wallet access, no order placement, no automatic trading.
"""

from __future__ import annotations

import argparse
import json
import math
import statistics
import sys
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any, Iterable

API_BASE = "https://gamma-api.polymarket.com/markets"
USER_AGENT = "Mozilla/5.0 (compatible; SafePolymarketScanner/0.1)"


@dataclass
class MarketScore:
    question: str
    slug: str
    event_title: str | None
    end_date: str | None
    yes_price: float | None
    no_price: float | None
    volume: float
    liquidity: float
    spread: float | None
    hours_to_end: float | None
    tags: list[str]
    score: float
    notes: list[str]


def api_get(url: str) -> Any:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def fetch_markets(limit: int, page_size: int = 100) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    offset = 0
    while len(results) < limit:
        batch_limit = min(page_size, limit - len(results))
        params = {
            "closed": "false",
            "archived": "false",
            "active": "true",
            "limit": str(batch_limit),
            "offset": str(offset),
        }
        url = f"{API_BASE}?{urllib.parse.urlencode(params)}"
        data = api_get(url)
        if not data:
            break
        results.extend(data)
        offset += len(data)
        if len(data) < batch_limit:
            break
    return results[:limit]


def parse_float(value: Any, default: float = 0.0) -> float:
    try:
        if value in (None, ""):
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def parse_price(value: Any) -> float | None:
    if value in (None, ""):
        return None
    try:
        x = float(value)
        if 0 <= x <= 1:
            return x
    except (TypeError, ValueError):
        return None
    return None


def parse_datetime(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        if value.endswith("Z"):
            value = value[:-1] + "+00:00"
        return datetime.fromisoformat(value).astimezone(timezone.utc)
    except ValueError:
        return None


def normalize(value: float, low: float, high: float) -> float:
    if high <= low:
        return 0.0
    value = max(low, min(high, value))
    return (value - low) / (high - low)


def classify_tags(question: str, tags: Iterable[dict[str, Any]] | None) -> list[str]:
    names = [str(t.get("label") or t.get("name") or "").strip() for t in (tags or [])]
    names = [n for n in names if n]
    q = question.lower()
    if any(k in q for k in ["will", "by ", "before ", "on "]):
        names.append("event-driven")
    if any(k in q for k in ["bitcoin", "ethereum", "solana", "crypto", "token"]):
        names.append("crypto")
    if any(k in q for k in ["trump", "election", "senate", "fed", "tariff", "president"]):
        names.append("politics-macro")
    return sorted(set(names))


def score_market(m: dict[str, Any], now: datetime) -> MarketScore:
    question = (m.get("question") or "").strip()
    event_title = (m.get("eventTitle") or m.get("title") or "").strip() or None
    slug = m.get("slug") or ""

    yes_price = parse_price(m.get("outcomePrices", [None])[0] if isinstance(m.get("outcomePrices"), list) and m.get("outcomePrices") else m.get("lastTradePrice"))
    no_price = parse_price(m.get("outcomePrices", [None, None])[1] if isinstance(m.get("outcomePrices"), list) and len(m.get("outcomePrices", [])) > 1 else None)

    best_ask = parse_price(m.get("bestAsk"))
    best_bid = parse_price(m.get("bestBid"))
    spread = None
    if best_ask is not None and best_bid is not None and best_ask >= best_bid:
        spread = best_ask - best_bid
    elif yes_price is not None and no_price is not None:
        # very rough proxy: pricing imbalance away from 1 may imply friction / uncertainty
        spread = abs(1 - (yes_price + no_price))

    volume = parse_float(m.get("volume") or m.get("volume24hr"))
    liquidity = parse_float(m.get("liquidity"))

    end_dt = parse_datetime(m.get("endDate"))
    hours_to_end = None
    if end_dt:
        hours_to_end = (end_dt - now).total_seconds() / 3600

    tags = classify_tags(question, m.get("tags"))
    if hours_to_end is not None and hours_to_end < -2:
        return MarketScore(
            question=question,
            slug=slug,
            event_title=event_title,
            end_date=m.get("endDate"),
            yes_price=yes_price,
            no_price=no_price,
            volume=volume,
            liquidity=liquidity,
            spread=spread,
            hours_to_end=hours_to_end,
            tags=tags,
            score=0.0,
            notes=["stale/expired market; skipped"],
        )
    notes: list[str] = []

    volume_score = normalize(math.log10(max(volume, 1.0)), 0, 6)
    liquidity_score = normalize(math.log10(max(liquidity, 1.0)), 0, 6)

    viability_penalty = 0.0

    spread_score = 0.0
    if spread is not None:
        # smaller spread is better for thin-margin trading
        spread_score = 1 - normalize(spread, 0.01, 0.15)
        if spread <= 0.03:
            notes.append("spread tight enough for thin-margin trades")
        elif spread >= 0.10:
            notes.append("spread wide; thin-margin edge may get eaten")
            viability_penalty += 0.15

    timing_score = 0.0
    if hours_to_end is not None:
        if 2 <= hours_to_end <= 168:
            timing_score = 1 - abs(hours_to_end - 24) / 144
            notes.append("within active event window")
        elif hours_to_end < 1:
            timing_score = 0.3
            notes.append("very near resolution; headline risk high")
            viability_penalty += 0.05
        elif 168 < hours_to_end <= 336:
            timing_score = 0.15
            notes.append("catalyst still far; lower short-term urgency")
            viability_penalty += 0.05
        elif hours_to_end > 336:
            notes.append("far from catalyst; likely too sleepy for short-term trading")
            viability_penalty += 0.25

    headline_bonus = 0.0
    if any(tag in tags for tag in ["event-driven", "crypto", "politics-macro"]):
        headline_bonus += 0.12
    if event_title:
        headline_bonus += 0.03

    score = (
        volume_score * 0.35
        + liquidity_score * 0.30
        + spread_score * 0.20
        + timing_score * 0.15
        + headline_bonus
        - viability_penalty
    ) * 100

    if volume < 10000:
        notes.append("volume low")
        viability_penalty += 0.10
    if liquidity < 5000:
        notes.append("liquidity low")
        viability_penalty += 0.10
    if yes_price is not None and 0.08 <= yes_price <= 0.92:
        notes.append("not pinned at extremes")
    else:
        notes.append("price near edge; momentum / binary risk higher")
        viability_penalty += 0.10

    score = max(0.0, score - viability_penalty * 100)

    return MarketScore(
        question=question,
        slug=slug,
        event_title=event_title,
        end_date=m.get("endDate"),
        yes_price=yes_price,
        no_price=no_price,
        volume=volume,
        liquidity=liquidity,
        spread=spread,
        hours_to_end=hours_to_end,
        tags=tags,
        score=round(score, 2),
        notes=notes,
    )


def format_report(scores: list[MarketScore], min_score: float) -> str:
    picked = [s for s in scores if s.score >= min_score]
    lines = []
    lines.append("# Safe Polymarket scanner report")
    lines.append("")
    lines.append(f"Candidates over threshold ({min_score:.0f}): {len(picked)} / {len(scores)}")
    lines.append("")
    for idx, s in enumerate(picked, 1):
        lines.append(f"## {idx}. {s.question}")
        lines.append(f"- score: {s.score}")
        if s.event_title:
            lines.append(f"- event: {s.event_title}")
        lines.append(f"- slug: {s.slug}")
        lines.append(f"- yes/no: {s.yes_price} / {s.no_price}")
        lines.append(f"- volume: {s.volume:.2f}")
        lines.append(f"- liquidity: {s.liquidity:.2f}")
        lines.append(f"- spread: {s.spread}")
        lines.append(f"- hours_to_end: {round(s.hours_to_end, 2) if s.hours_to_end is not None else 'n/a'}")
        lines.append(f"- tags: {', '.join(s.tags) if s.tags else 'n/a'}")
        lines.append(f"- notes: {'; '.join(s.notes)}")
        lines.append("")
    return "\n".join(lines)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Safe Polymarket scanner prototype")
    p.add_argument("--limit", type=int, default=200, help="How many open markets to scan")
    p.add_argument("--top", type=int, default=15, help="How many scored markets to keep")
    p.add_argument("--min-score", type=float, default=45.0, help="Minimum score to print")
    p.add_argument("--json", action="store_true", help="Output JSON instead of markdown")
    p.add_argument("--save", help="Optional path to save report")
    return p


def main() -> int:
    args = build_parser().parse_args()
    now = datetime.now(timezone.utc)
    markets = fetch_markets(args.limit)
    scores = [score_market(m, now) for m in markets]
    scores.sort(key=lambda x: x.score, reverse=True)
    scores = scores[: args.top]

    if args.json:
        output = json.dumps([asdict(s) for s in scores if s.score >= args.min_score], ensure_ascii=False, indent=2)
    else:
        output = format_report(scores, args.min_score)

    print(output)
    if args.save:
        with open(args.save, "w", encoding="utf-8") as f:
            f.write(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
