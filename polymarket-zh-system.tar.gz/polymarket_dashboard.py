#!/usr/bin/env python3
"""生成 Polymarket 中文仪表盘页面。"""

from __future__ import annotations

import json
from datetime import datetime
from html import escape
from pathlib import Path
from typing import Any

STATE = Path("state/polymarket-monitor-state.json")
LEDGER = Path("state/polymarket-paper-ledger.json")
OUT = Path("reports/polymarket-dashboard.html")

BUCKET_LABELS = {
    "crypto": "加密市场",
    "macro": "宏观/政治",
    "ai": "AI/科技",
    "geopolitics": "地缘政治",
    "other": "其他",
    "n/a": "未知",
}

REASON_LABELS = {
    "target": "止盈",
    "stop": "止损",
    "time": "到时平仓",
}


def load(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def pnl_color(x: float) -> str:
    if x > 0:
        return "#16a34a"
    if x < 0:
        return "#dc2626"
    return "#64748b"


def fmt_ts(ts: int | None) -> str:
    if not ts:
        return "暂无"
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")


def bucket_label(v: str | None) -> str:
    return BUCKET_LABELS.get(v or "n/a", v or "未知")


def reason_label(v: str | None) -> str:
    return REASON_LABELS.get(v or "", v or "未知")


def render() -> str:
    state = load(STATE, {"markets": {}, "alerts": {}})
    ledger = load(LEDGER, {"open_positions": {}, "closed_positions": []})

    markets = sorted(
        state.get("markets", {}).values(),
        key=lambda x: x.get("signal_score", 0),
        reverse=True,
    )
    top = [m for m in markets if m.get("signal_score", 0) > 0][:20]
    open_positions = ledger.get("open_positions", {})
    closed_positions = ledger.get("closed_positions", [])[-20:][::-1]

    total_pnl = round(sum(float(x.get("pnl", 0)) for x in closed_positions), 4)
    wins = sum(1 for x in closed_positions if float(x.get("pnl", 0)) > 0)
    trades = len(closed_positions)
    win_rate = round((wins / trades) * 100, 2) if trades else 0.0

    cards = f"""
    <div class='cards'>
      <div class='card'><div class='label'>跟踪市场数</div><div class='value'>{len(markets)}</div></div>
      <div class='card'><div class='label'>当前高分信号</div><div class='value'>{len(top)}</div></div>
      <div class='card'><div class='label'>模拟持仓数</div><div class='value'>{len(open_positions)}</div></div>
      <div class='card'><div class='label'>已平仓模拟单</div><div class='value'>{trades}</div></div>
      <div class='card'><div class='label'>胜率</div><div class='value'>{win_rate}%</div></div>
      <div class='card'><div class='label'>近期盈亏</div><div class='value' style='color:{pnl_color(total_pnl)}'>{total_pnl}</div></div>
    </div>
    """

    top_rows = []
    for m in top:
        url = f"https://polymarket.com/event/{escape(str(m.get('slug','')))}"
        notes = escape('；'.join((m.get('signal_notes') or [])[:4]))
        top_rows.append(
            f"<tr>"
            f"<td><a href='{url}' target='_blank'>{escape(str(m.get('question','')))}</a></td>"
            f"<td>{escape(bucket_label(str(m.get('bucket','n/a'))))}</td>"
            f"<td>{m.get('signal_score', 0)}</td>"
            f"<td>{m.get('yes_price','暂无')}</td>"
            f"<td>{m.get('spread','暂无')}</td>"
            f"<td>{round(float(m.get('volume24hr',0)),2)}</td>"
            f"<td>{round(float(m.get('liquidity',0)),2)}</td>"
            f"<td>{'通过' if m.get('watchlist_pass') else '未通过'}</td>"
            f"<td>{notes}</td>"
            f"</tr>"
        )

    open_rows = []
    for _, p in open_positions.items():
        open_rows.append(
            f"<tr>"
            f"<td>{escape(str(p.get('question','')))}</td>"
            f"<td>{escape(bucket_label(str(p.get('bucket','n/a'))))}</td>"
            f"<td>{p.get('entry_price')}</td>"
            f"<td>{p.get('target_price')}</td>"
            f"<td>{p.get('stop_price')}</td>"
            f"<td>{p.get('score_at_entry')}</td>"
            f"<td>{fmt_ts(p.get('entry_ts'))}</td>"
            f"</tr>"
        )

    closed_rows = []
    for p in closed_positions:
        pnl = float(p.get('pnl', 0))
        closed_rows.append(
            f"<tr>"
            f"<td>{escape(str(p.get('question','')))}</td>"
            f"<td>{p.get('entry_price')}</td>"
            f"<td>{p.get('exit_price')}</td>"
            f"<td style='color:{pnl_color(pnl)}'>{pnl}</td>"
            f"<td>{escape(reason_label(str(p.get('reason',''))))}</td>"
            f"<td>{fmt_ts(p.get('exit_ts'))}</td>"
            f"</tr>"
        )

    html = f"""
<!doctype html>
<html>
<head>
  <meta charset='utf-8'>
  <meta name='viewport' content='width=device-width, initial-scale=1'>
  <title>Polymarket 中文仪表盘</title>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, sans-serif; background: #0f172a; color: #e2e8f0; margin: 0; padding: 24px; }}
    h1,h2 {{ margin: 0 0 16px; }}
    .muted {{ color: #94a3b8; margin-bottom: 20px; }}
    .cards {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; margin-bottom: 24px; }}
    .card {{ background: #111827; border: 1px solid #1f2937; border-radius: 12px; padding: 16px; }}
    .label {{ color: #94a3b8; font-size: 13px; margin-bottom: 8px; }}
    .value {{ font-size: 28px; font-weight: 700; }}
    .panel {{ background: #111827; border: 1px solid #1f2937; border-radius: 12px; padding: 16px; margin-bottom: 20px; overflow-x: auto; }}
    table {{ width: 100%; border-collapse: collapse; font-size: 14px; }}
    th, td {{ text-align: left; padding: 10px 8px; border-bottom: 1px solid #1f2937; vertical-align: top; }}
    th {{ color: #93c5fd; }}
    a {{ color: #60a5fa; text-decoration: none; }}
    .empty {{ color: #64748b; padding: 12px 0; }}
  </style>
</head>
<body>
  <h1>Polymarket 中文仪表盘</h1>
  <div class='muted'>生成时间：{fmt_ts(int(datetime.now().timestamp()))}</div>
  {cards}

  <div class='panel'>
    <h2>当前高分信号</h2>
    {('<table><thead><tr><th>问题</th><th>市场类型</th><th>评分</th><th>YES价格</th><th>买卖价差</th><th>24小时成交量</th><th>流动性</th><th>是否通过筛选</th><th>说明</th></tr></thead><tbody>' + ''.join(top_rows) + '</tbody></table>') if top_rows else "<div class='empty'>暂无高分信号。</div>"}
  </div>

  <div class='panel'>
    <h2>模拟持仓</h2>
    {('<table><thead><tr><th>问题</th><th>市场类型</th><th>入场价</th><th>止盈价</th><th>止损价</th><th>入场评分</th><th>开仓时间</th></tr></thead><tbody>' + ''.join(open_rows) + '</tbody></table>') if open_rows else "<div class='empty'>暂无模拟持仓。</div>"}
  </div>

  <div class='panel'>
    <h2>最近已平仓模拟单</h2>
    {('<table><thead><tr><th>问题</th><th>入场价</th><th>出场价</th><th>盈亏</th><th>原因</th><th>平仓时间</th></tr></thead><tbody>' + ''.join(closed_rows) + '</tbody></table>') if closed_rows else "<div class='empty'>暂无已平仓模拟单。</div>"}
  </div>
</body>
</html>
    """
    return html


def main() -> int:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(render(), encoding="utf-8")
    print(str(OUT))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
