#!/usr/bin/env bash
set -euo pipefail
ROOT="/Users/_3gxpgs/.openclaw/workspace"
open "$ROOT/reports/polymarket-dashboard.html"
open "$ROOT/reports/polymarket-history-report.html"
echo "已经打开：中文仪表盘 + 中文长期历史报告。"
