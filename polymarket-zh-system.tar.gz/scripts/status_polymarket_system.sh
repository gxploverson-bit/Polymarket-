#!/usr/bin/env bash
set -euo pipefail
ROOT="/Users/_3gxpgs/.openclaw/workspace"

echo "=== 进程检查 ==="
pgrep -af 'run_polymarket_monitor.sh watchlists/crypto_loose.json' || echo '当前没有运行'

echo
echo "=== 最新日志（最后30行） ==="
if [[ -f "$ROOT/logs/polymarket-monitor.log" ]]; then
  tail -n 30 "$ROOT/logs/polymarket-monitor.log"
else
  echo '还没有日志文件'
fi

echo
echo "=== 仪表盘 ==="
echo "$ROOT/reports/polymarket-dashboard.html"

echo
echo "=== 长期历史报告 ==="
echo "$ROOT/reports/polymarket-history-report.html"
