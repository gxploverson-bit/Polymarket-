#!/usr/bin/env bash
set -euo pipefail
pkill -f 'run_polymarket_monitor.sh watchlists/crypto_loose.json' >/dev/null 2>&1 || true
echo "Polymarket 系统已停止（如果刚才在运行的话）。"
