#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PLIST_SRC="$ROOT/scripts/ai.openclaw.polymarket-monitor.plist"
PLIST_DST="$HOME/Library/LaunchAgents/ai.openclaw.polymarket-monitor.plist"

mkdir -p "$HOME/Library/LaunchAgents"
cp "$PLIST_SRC" "$PLIST_DST"
launchctl unload "$PLIST_DST" >/dev/null 2>&1 || true
launchctl load "$PLIST_DST"
launchctl enable "gui/$(id -u)/ai.openclaw.polymarket-monitor" >/dev/null 2>&1 || true
launchctl kickstart -k "gui/$(id -u)/ai.openclaw.polymarket-monitor" >/dev/null 2>&1 || true

echo "installed: $PLIST_DST"
echo "status: launchctl print gui/$(id -u)/ai.openclaw.polymarket-monitor | head"
