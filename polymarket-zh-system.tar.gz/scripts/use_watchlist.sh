#!/usr/bin/env bash
set -euo pipefail

MODE="${1:-}"
if [[ -z "$MODE" ]]; then
  echo "usage: $0 <crypto|crypto_loose|macro|macro_loose|ai|geopolitics>"
  exit 1
fi

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/watchlists/${MODE}.json"
DST="$ROOT/polymarket_watchlist.json"

if [[ ! -f "$SRC" ]]; then
  echo "unknown watchlist preset: $MODE"
  exit 1
fi

cp "$SRC" "$DST"
echo "active watchlist -> $MODE"
