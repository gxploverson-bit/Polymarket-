#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

WATCHLIST="${1:-polymarket_watchlist.json}"
INTERVAL="${INTERVAL_SECONDS:-60}"
LIMIT="${LIMIT:-150}"
TOP="${TOP:-10}"
ALERT_THRESHOLD="${ALERT_THRESHOLD:-55}"
PAPER_OPEN_THRESHOLD="${PAPER_OPEN_THRESHOLD:-65}"
EXTRA_ARGS="${EXTRA_ARGS:-}"

mkdir -p logs state
LOG_FILE="logs/polymarket-monitor.log"

echo "[$(date '+%F %T')] starting monitor watchlist=$WATCHLIST interval=${INTERVAL}s" | tee -a "$LOG_FILE"

while true; do
  {
    echo "===== $(date '+%F %T') ====="
    python3 polymarket_monitor.py \
      --watchlist "$WATCHLIST" \
      --limit "$LIMIT" \
      --top "$TOP" \
      --alert-threshold "$ALERT_THRESHOLD" \
      --paper-open-threshold "$PAPER_OPEN_THRESHOLD" \
      ${TELEGRAM_ENABLED:+--telegram} \
      $EXTRA_ARGS
    python3 polymarket_dashboard.py
    python3 polymarket_candidates.py
    python3 polymarket_history_report.py
    echo
  } >> "$LOG_FILE" 2>&1 || true
  sleep "$INTERVAL"
done
