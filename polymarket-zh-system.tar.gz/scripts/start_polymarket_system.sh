#!/usr/bin/env bash
set -euo pipefail

ROOT="/Users/_3gxpgs/.openclaw/workspace"
cd "$ROOT"

bash scripts/use_watchlist.sh crypto_loose
nohup bash scripts/run_polymarket_monitor.sh watchlists/crypto_loose.json > /tmp/polymarket-system-bootstrap.log 2>&1 &
sleep 2
open reports/polymarket-dashboard.html || true

echo "Polymarket 系统已启动。"
echo "仪表盘：$ROOT/reports/polymarket-dashboard.html"
echo "主日志：$ROOT/logs/polymarket-monitor.log"
echo "启动日志：/tmp/polymarket-system-bootstrap.log"
echo "以后要停止，运行：bash $ROOT/scripts/stop_polymarket_system.sh"
