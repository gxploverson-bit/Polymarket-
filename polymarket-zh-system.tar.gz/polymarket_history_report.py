#!/usr/bin/env python3
"""生成 Polymarket 中文长期历史报告。"""

from __future__ import annotations

import json
from datetime import datetime
from html import escape
from pathlib import Path
from statistics import mean
from typing import Any

HISTORY = Path("state/polymarket-history.json")
STATE = Path("state/polymarket-monitor-state.json")
CANDIDATES = Path("reports/polymarket-candidates.json")
OUT = Path("reports/polymarket-history-report.html")

BUCKET_LABELS = {
    "crypto": "加密市场",
    "macro": "宏观/政治",
    "ai": "AI/科技",
    "geopolitics": "地缘政治",
    "other": "其他",
    "n/a": "未知",
}


def load(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def fmt_ts(ts: int | None) -> str:
    if not ts:
        return "暂无"
    return datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")


def bucket_label(v: str | None) -> str:
    return BUCKET_LABELS.get(v or "n/a", v or "未知")


def main() -> int:
    history = load(HISTORY, {})
    state = load(STATE, {"markets": {}})
    candidates = load(CANDIDATES, [])

    rows = []
    for slug, entries in history.items():
        if len(entries) < 2:
            continue
        prices = [e.get("yes_price") for e in entries if e.get("yes_price") is not None]
        vols = [float(e.get("volume24hr") or 0) for e in entries]
        spreads = [e.get("spread") for e in entries if e.get("spread") is not None]
        if not prices:
            continue
        m = state.get("markets", {}).get(slug, {})
        rows.append({
            "slug": slug,
            "question": m.get("question") or slug,
            "bucket": m.get("bucket") or "n/a",
            "snapshots": len(entries),
            "last_seen": entries[-1].get("ts"),
            "price_min": min(prices),
            "price_max": max(prices),
            "price_range": max(prices) - min(prices),
            "vol_avg": mean(vols) if vols else 0,
            "spread_avg": mean(spreads) if spreads else None,
        })

    rows.sort(key=lambda x: x["price_range"], reverse=True)
    top_hist = rows[:20]
    top_candidates = candidates[:20]

    hist_rows = ''.join(
        f"<tr><td>{escape(r['question'])}</td><td>{escape(bucket_label(str(r['bucket'])))}</td><td>{r['snapshots']}</td><td>{r['price_min']:.3f}</td><td>{r['price_max']:.3f}</td><td>{r['price_range']:.3f}</td><td>{r['vol_avg']:.1f}</td><td>{round(r['spread_avg'],4) if r['spread_avg'] is not None else '暂无'}</td><td>{fmt_ts(r['last_seen'])}</td></tr>"
        for r in top_hist
    )

    cand_rows = ''.join(
        f"<tr><td>{escape(r['question'])}</td><td>{escape(bucket_label(str(r['bucket'])))}</td><td>{r['candidate_score']}</td><td>{r['appearances']}</td><td>{r['price_range']}</td><td>{r['momentum']}</td><td>{r['vol24h_avg']}</td><td>{r['spread_best']}</td><td>{r['latest_signal_score']}</td></tr>"
        for r in top_candidates
    )

    html = f"""<!doctype html>
<html>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<title>Polymarket 中文长期历史报告</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, sans-serif; background:#0f172a; color:#e2e8f0; margin:0; padding:24px; }}
h1,h2 {{ margin:0 0 16px; }}
.panel {{ background:#111827; border:1px solid #1f2937; border-radius:12px; padding:16px; margin-bottom:20px; overflow-x:auto; }}
table {{ width:100%; border-collapse:collapse; font-size:14px; }}
th,td {{ text-align:left; padding:10px 8px; border-bottom:1px solid #1f2937; vertical-align:top; }}
th {{ color:#93c5fd; }}
.muted {{ color:#94a3b8; margin-bottom:16px; }}
.empty {{ color:#64748b; padding:12px 0; }}
</style>
</head>
<body>
<h1>Polymarket 中文长期历史报告</h1>
<div class='muted'>生成时间：{fmt_ts(int(datetime.now().timestamp()))}</div>
<div class='panel'>
<h2>候选池排行</h2>
{('<table><thead><tr><th>问题</th><th>市场类型</th><th>候选评分</th><th>出现次数</th><th>价格波动范围</th><th>动量</th><th>24小时均量</th><th>最佳价差</th><th>最新信号评分</th></tr></thead><tbody>' + cand_rows + '</tbody></table>') if cand_rows else "<div class='empty'>候选池暂时还没有内容，继续挂着跑让系统积累数据。</div>"}
</div>
<div class='panel'>
<h2>历史活跃市场</h2>
{('<table><thead><tr><th>问题</th><th>市场类型</th><th>快照数</th><th>最低价</th><th>最高价</th><th>波动范围</th><th>24小时平均成交量</th><th>平均价差</th><th>最后出现时间</th></tr></thead><tbody>' + hist_rows + '</tbody></table>') if hist_rows else "<div class='empty'>历史样本还太少，先让系统继续运行。</div>"}
</div>
</body>
</html>"""

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(html, encoding='utf-8')
    print(str(OUT))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
