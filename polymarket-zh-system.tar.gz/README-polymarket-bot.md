# Safe Polymarket Scanner + Monitor

This workspace now includes three read-only tools:

- `polymarket_bot.py` — one-shot scanner and market scorer
- `polymarket_monitor.py` — continuous monitor with anomaly detection, watchlist filtering, Telegram alerts, and paper trading ledger
- `polymarket_stats.py` — paper-trading performance summary

Neither tool places orders or connects a wallet.

## Why this setup
Because full automation before verified edge and hard risk controls is a neat way to automate losses.

This stack is built in the safer order:
1. scan
2. monitor
3. watchlist filter
4. alert
5. paper trade
6. only then consider semi-automation

---

## 1) Scanner

### Basic scan
```bash
python3 polymarket_bot.py
```

### Scan more markets and keep top 20
```bash
python3 polymarket_bot.py --limit 300 --top 20
```

### Save markdown report
```bash
python3 polymarket_bot.py --save reports/polymarket-report.md
```

### JSON output
```bash
python3 polymarket_bot.py --json > reports/polymarket-report.json
```

---

## 2) Continuous monitor

Runs one monitoring pass:
```bash
python3 polymarket_monitor.py
```

A useful manual run:
```bash
python3 polymarket_monitor.py --limit 150 --top 10 --alert-threshold 55 --paper-open-threshold 65
```

### Watchlist mode
The monitor loads `polymarket_watchlist.json` by default.
This file lets you:
- focus on specific themes (crypto / macro / politics / AI / geopolitics)
- exclude obvious garbage / long-horizon sports markets
- restrict event window
- set minimum liquidity / volume / maximum spread

Run with explicit watchlist path if needed:
```bash
python3 polymarket_monitor.py --watchlist polymarket_watchlist.json
```

### Telegram alerts
Set environment variables first:
```bash
export TELEGRAM_BOT_TOKEN="your_bot_token"
export TELEGRAM_CHAT_ID="your_chat_id"
python3 polymarket_monitor.py --telegram
```

---

## 3) Watchlist presets

Preset files live in `watchlists/`:
- `watchlists/crypto.json`
- `watchlists/crypto_loose.json`
- `watchlists/macro.json`
- `watchlists/macro_loose.json`
- `watchlists/ai.json`
- `watchlists/geopolitics.json`

Switch active preset:
```bash
bash scripts/use_watchlist.sh crypto
bash scripts/use_watchlist.sh crypto_loose
bash scripts/use_watchlist.sh macro
bash scripts/use_watchlist.sh macro_loose
bash scripts/use_watchlist.sh ai
bash scripts/use_watchlist.sh geopolitics
```

That copies the chosen preset into `polymarket_watchlist.json`.

---

## 4) One-click start

If you just want the easiest beginner path, run:
```bash
bash /Users/_3gxpgs/.openclaw/workspace/scripts/start_polymarket_system.sh
```

It will:
- switch to `crypto_loose`
- start the monitor in background
- try to open the dashboard
- print where the logs are

Stop it:
```bash
bash /Users/_3gxpgs/.openclaw/workspace/scripts/stop_polymarket_system.sh
```

Check status:
```bash
bash /Users/_3gxpgs/.openclaw/workspace/scripts/status_polymarket_system.sh
```

Open reports:
```bash
bash /Users/_3gxpgs/.openclaw/workspace/scripts/open_polymarket_reports.sh
```

---

## 5) Background / long-running mode

Run the monitor continuously with logs:
```bash
bash scripts/run_polymarket_monitor.sh
```

Run with a specific preset:
```bash
bash scripts/run_polymarket_monitor.sh watchlists/crypto.json
```

Useful environment variables:
```bash
export TELEGRAM_ENABLED=1
export TELEGRAM_BOT_TOKEN="your_bot_token"
export TELEGRAM_CHAT_ID="your_chat_id"
export INTERVAL_SECONDS=60
export LIMIT=150
export TOP=10
export ALERT_THRESHOLD=55
export PAPER_OPEN_THRESHOLD=65
```

Logs will be written to:
- `logs/polymarket-monitor.log`

---

## 5) macOS launchd service

If you want the monitor to run automatically in the background on this Mac:

### Install
```bash
bash scripts/install_polymarket_launchd.sh
```

### Uninstall
```bash
bash scripts/uninstall_polymarket_launchd.sh
```

### Template plist
The launchd template lives at:
- `scripts/ai.openclaw.polymarket-monitor.plist`

Default behavior in the template:
- uses the `crypto` preset
- runs every 60 seconds via the wrapper loop
- writes logs to workspace `logs/`

Before installing, edit the plist command if you want a different preset or interval.
Also make sure your Telegram bot environment is available if you expect alert delivery from launchd.

Useful checks:
```bash
launchctl print gui/$(id -u)/ai.openclaw.polymarket-monitor | head
ls -l ~/Library/LaunchAgents/ai.openclaw.polymarket-monitor.plist
```

---

## 6) Candidate pool + long-term history report

Build the candidate pool and long-term history report:
```bash
bash scripts/build_polymarket_history_report.sh
```

Outputs:
- `reports/polymarket-candidates.json`
- `reports/polymarket-history-report.html`

What they are for:
- find markets that repeatedly look interesting even if they never cross the live alert threshold
- rank markets by repeated appearances, price range, momentum, spread quality, and volume
- surface long-term movers instead of only current-cycle signals

The long-running monitor now refreshes these automatically on each cycle.

---

## 7) HTML dashboard

Build the dashboard manually:
```bash
bash scripts/build_polymarket_dashboard.sh
```

Output:
- `reports/polymarket-dashboard.html`

The long-running monitor script now rebuilds the dashboard on each cycle, so if the monitor is running in background, the HTML report stays fresh.

---

## 8) Paper-trading stats

Summarize paper-trade results:
```bash
python3 polymarket_stats.py
```

JSON output:
```bash
python3 polymarket_stats.py --json
```

It reports:
- total trades
- wins / losses
- win rate
- total pnl
- average pnl
- max drawdown
- reason breakdown (target / stop / time)
- bucket breakdown (crypto / macro-politics / ai-tech / geopolitics / other)

---

## What the monitor does

### Anomaly detection
It scores markets using:
- liquidity
- 24h volume
- spread
- event timing window
- current price not pinned at extremes
- 1h price change
- movement since last scan
- volume acceleration
- spread improvement

### Watchlist filtering
Only watchlist-approved markets can:
- trigger alerts
- open paper trades
- appear as serious candidates

### Telegram alerting
If a market score crosses the alert threshold and cooldown has passed, it sends a formatted alert.

### Paper trading
When a market score crosses the paper open threshold, the monitor can simulate a position.

Default paper rules:
- entry: current YES price when threshold triggers
- target: +0.03
- stop: -0.02
- max hold: 90 minutes

Ledger file:
- `state/polymarket-paper-ledger.json`

State cache:
- `state/polymarket-monitor-state.json`
- `state/polymarket-history.json`

Watchlist config:
- `polymarket_watchlist.json`

---

## Files
- `polymarket_bot.py`
- `polymarket_monitor.py`
- `polymarket_stats.py`
- `polymarket_watchlist.json`
- `watchlists/*.json`
- `scripts/run_polymarket_monitor.sh`
- `scripts/use_watchlist.sh`
- `scripts/install_polymarket_launchd.sh`
- `scripts/uninstall_polymarket_launchd.sh`
- `scripts/ai.openclaw.polymarket-monitor.plist`
- `scripts/build_polymarket_dashboard.sh`
- `scripts/build_polymarket_history_report.sh`
- `reports/polymarket-report.md`
- `reports/polymarket-dashboard.html`
- `reports/polymarket-candidates.json`
- `reports/polymarket-history-report.html`
- `logs/polymarket-monitor.log`
- `logs/polymarket-launchd.out.log`
- `logs/polymarket-launchd.err.log`
- `state/polymarket-monitor-state.json`
- `state/polymarket-paper-ledger.json`

---

## Suggested next upgrades
- better event-window classification
- multi-snapshot momentum scoring
- CSV export for paper trade analysis
- dashboard / mini web UI
- semi-automatic limit-order suggestions
- smarter launchd env injection for Telegram secrets

---

## Hard rules if you use this in real life
- single trade risk: 1% to 3% of bankroll max
- stop after 3 consecutive losses
- stop for the day after 3% to 5% drawdown
- never use rent / survival money for prediction markets
- never turn paper-trade logic into live trading without checking fills, slippage, spread, and resolution rules
