#!/usr/bin/env python3
"""Build a candidate-pool summary from historical Polymarket snapshots."""

from __future__ import annotations

import json
from pathlib import Path
from statistics import mean
from typing import Any

HISTORY = Path("state/polymarket-history.json")
STATE = Path("state/polymarket-monitor-state.json")
OUT = Path("reports/polymarket-candidates.json")


def load(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def summarize_entries(slug: str, entries: list[dict[str, Any]], state_market: dict[str, Any] | None) -> dict[str, Any] | None:
    if len(entries) < 3:
        return None
    prices = [e.get("yes_price") for e in entries if e.get("yes_price") is not None]
    spreads = [e.get("spread") for e in entries if e.get("spread") is not None]
    vols = [float(e.get("volume24hr") or 0) for e in entries]
    if not prices:
        return None

    price_range = max(prices) - min(prices)
    momentum = prices[-1] - prices[0]
    spread_avg = mean(spreads) if spreads else None
    spread_best = min(spreads) if spreads else None
    vol_avg = mean(vols) if vols else 0.0
    vol_peak = max(vols) if vols else 0.0
    appearances = len(entries)

    score = 0.0
    score += min(price_range * 300, 30)
    score += min(abs(momentum) * 200, 20)
    score += min(vol_avg / 2000, 20)
    score += min(vol_peak / 3000, 20)
    if spread_best is not None:
        score += max(0, (0.05 - spread_best) * 200)
    score += min(appearances / 3, 10)

    return {
        "slug": slug,
        "question": (state_market or {}).get("question") or slug,
        "bucket": (state_market or {}).get("bucket") or "n/a",
        "watchlist_pass": (state_market or {}).get("watchlist_pass"),
        "latest_signal_score": (state_market or {}).get("signal_score", 0),
        "appearances": appearances,
        "price_range": round(price_range, 4),
        "momentum": round(momentum, 4),
        "spread_avg": round(spread_avg, 4) if spread_avg is not None else None,
        "spread_best": round(spread_best, 4) if spread_best is not None else None,
        "vol24h_avg": round(vol_avg, 2),
        "vol24h_peak": round(vol_peak, 2),
        "candidate_score": round(score, 2),
    }


def main() -> int:
    history = load(HISTORY, {})
    state = load(STATE, {"markets": {}})
    markets = state.get("markets", {})
    rows = []
    for slug, entries in history.items():
        row = summarize_entries(slug, entries, markets.get(slug))
        if row:
            rows.append(row)
    rows.sort(key=lambda x: x["candidate_score"], reverse=True)
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    print(str(OUT))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
