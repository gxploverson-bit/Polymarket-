#!/usr/bin/env python3
"""Continuous Polymarket monitor with anomaly detection and paper-trading.

Safe by default:
- read-only against Polymarket public APIs
- no wallet access
- no order placement
- optional Telegram alerts via bot token + chat id
- optional paper trading ledger for simulated entries/exits
"""

from __future__ import annotations

import argparse
import json
import math
import os
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

WATCHLIST_PATH = Path("polymarket_watchlist.json")

API_BASE = "https://gamma-api.polymarket.com/markets"
USER_AGENT = "Mozilla/5.0 (compatible; SafePolymarketMonitor/0.2)"
DEFAULT_STATE = Path("state/polymarket-monitor-state.json")
DEFAULT_LEDGER = Path("state/polymarket-paper-ledger.json")
DEFAULT_HISTORY = Path("state/polymarket-history.json")


@dataclass
class Snapshot:
    ts: int
    question: str
    slug: str
    yes_price: float | None
    best_bid: float | None
    best_ask: float | None
    spread: float | None
    volume: float
    volume24hr: float
    liquidity: float
    one_hour_change: float
    one_day_change: float
    end_date: str | None
    hours_to_end: float | None


def api_get(url: str) -> Any:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def parse_float(value: Any, default: float = 0.0) -> float:
    try:
        if value in (None, ""):
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def parse_price(value: Any) -> float | None:
    try:
        if value in (None, ""):
            return None
        x = float(value)
        if 0 <= x <= 1:
            return x
    except (TypeError, ValueError):
        return None
    return None


def parse_datetime(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        if value.endswith("Z"):
            value = value[:-1] + "+00:00"
        return datetime.fromisoformat(value).astimezone(timezone.utc)
    except ValueError:
        return None


def fetch_markets(limit: int) -> list[dict[str, Any]]:
    params = {
        "closed": "false",
        "archived": "false",
        "active": "true",
        "limit": str(limit),
        "offset": "0",
    }
    url = f"{API_BASE}?{urllib.parse.urlencode(params)}"
    return api_get(url)


def make_snapshot(m: dict[str, Any], now_ts: int) -> Snapshot:
    outcomes = m.get("outcomePrices") or []
    yes_price = parse_price(outcomes[0]) if isinstance(outcomes, list) and outcomes else parse_price(m.get("lastTradePrice"))
    best_bid = parse_price(m.get("bestBid"))
    best_ask = parse_price(m.get("bestAsk"))
    spread = None
    if best_bid is not None and best_ask is not None and best_ask >= best_bid:
        spread = best_ask - best_bid
    end_dt = parse_datetime(m.get("endDate"))
    hours_to_end = None
    if end_dt:
        hours_to_end = (end_dt - datetime.now(timezone.utc)).total_seconds() / 3600
    return Snapshot(
        ts=now_ts,
        question=(m.get("question") or "").strip(),
        slug=m.get("slug") or str(m.get("id") or ""),
        yes_price=yes_price,
        best_bid=best_bid,
        best_ask=best_ask,
        spread=spread,
        volume=parse_float(m.get("volume")),
        volume24hr=parse_float(m.get("volume24hr")),
        liquidity=parse_float(m.get("liquidity")),
        one_hour_change=parse_float(m.get("oneHourPriceChange")),
        one_day_change=parse_float(m.get("oneDayPriceChange")),
        end_date=m.get("endDate"),
        hours_to_end=hours_to_end,
    )


def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def load_watchlist(path: Path) -> dict[str, Any]:
    return load_json(path, {
        "keywords": {"include_any": [], "exclude_any": []},
        "slug_include_any": [],
        "hours_to_end": {"min": 0, "max": 336},
        "thresholds": {"min_liquidity": 5000, "min_volume24h": 5000, "max_spread": 0.05},
    })


def classify_market(cur: Snapshot) -> str:
    q = cur.question.lower()
    if any(k in q for k in ["bitcoin", "ethereum", "solana", "crypto", "token", "etf", "airdrop", "defi"]):
        return "crypto"
    if any(k in q for k in ["fed", "cpi", "inflation", "rate cut", "tariff", "trump", "election", "senate", "president", "gdp", "jobs report"]):
        return "macro"
    if any(k in q for k in ["openai", "gpt", "ai", "anthropic", "gemini", "chatgpt", "hardware", "model"]):
        return "ai"
    if any(k in q for k in ["ukraine", "ceasefire", "china", "taiwan", "war", "israel", "gaza", "nato", "russia"]):
        return "geopolitics"
    return "other"


def strategy_profile(bucket: str) -> dict[str, float]:
    profiles = {
        "crypto": {"ideal_h_min": 1, "ideal_h_max": 120, "liq_good": 8000, "v_good": 12000, "target": 0.035, "stop": 0.02, "hold_min": 120},
        "macro": {"ideal_h_min": 1, "ideal_h_max": 72, "liq_good": 10000, "v_good": 15000, "target": 0.03, "stop": 0.018, "hold_min": 90},
        "ai": {"ideal_h_min": 1, "ideal_h_max": 168, "liq_good": 4000, "v_good": 5000, "target": 0.04, "stop": 0.02, "hold_min": 180},
        "geopolitics": {"ideal_h_min": 1, "ideal_h_max": 240, "liq_good": 7000, "v_good": 8000, "target": 0.035, "stop": 0.02, "hold_min": 180},
        "other": {"ideal_h_min": 1, "ideal_h_max": 96, "liq_good": 10000, "v_good": 10000, "target": 0.03, "stop": 0.02, "hold_min": 90},
    }
    return profiles[bucket]


def passes_watchlist(cur: Snapshot, watchlist: dict[str, Any]) -> tuple[bool, list[str]]:
    reasons = []
    q = cur.question.lower()
    slug = cur.slug.lower()
    include_any = [x.lower() for x in watchlist.get("keywords", {}).get("include_any", [])]
    exclude_any = [x.lower() for x in watchlist.get("keywords", {}).get("exclude_any", [])]
    slug_include = [x.lower() for x in watchlist.get("slug_include_any", [])]

    if include_any and not any(k in q for k in include_any) and not any(k in slug for k in slug_include):
        reasons.append("not in watchlist focus")
    if exclude_any and any(k in q for k in exclude_any):
        reasons.append("explicitly excluded by watchlist")

    h = watchlist.get("hours_to_end", {})
    hmin = h.get("min")
    hmax = h.get("max")
    if cur.hours_to_end is not None:
        if hmin is not None and cur.hours_to_end < hmin:
            reasons.append("below min event window")
        if hmax is not None and cur.hours_to_end > hmax:
            reasons.append("beyond max event window")

    t = watchlist.get("thresholds", {})
    if cur.liquidity < float(t.get("min_liquidity", 0)):
        reasons.append("below watchlist min liquidity")
    if cur.volume24hr < float(t.get("min_volume24h", 0)):
        reasons.append("below watchlist min 24h volume")
    max_spread = t.get("max_spread")
    if max_spread is not None and cur.spread is not None and cur.spread > float(max_spread):
        reasons.append("spread above watchlist max")

    return (len(reasons) == 0, reasons)


def update_history(history: dict[str, Any], cur: Snapshot) -> list[dict[str, Any]]:
    entries = history.setdefault(cur.slug, [])
    entries.append({
        "ts": cur.ts,
        "yes_price": cur.yes_price,
        "spread": cur.spread,
        "volume24hr": cur.volume24hr,
        "liquidity": cur.liquidity,
        "one_hour_change": cur.one_hour_change,
    })
    if len(entries) > 120:
        del entries[:-120]
    return entries


def history_features(entries: list[dict[str, Any]], cur: Snapshot) -> tuple[float, list[str]]:
    if len(entries) < 3 or cur.yes_price is None:
        return 0.0, []
    notes = []
    score = 0.0
    recent = entries[-12:]
    prices = [e.get("yes_price") for e in recent if e.get("yes_price") is not None]
    spreads = [e.get("spread") for e in recent if e.get("spread") is not None]
    vols = [float(e.get("volume24hr") or 0) for e in recent]

    if len(prices) >= 3:
        pmin, pmax = min(prices), max(prices)
        if pmax - pmin >= 0.03:
            score += 8
            notes.append("recent price range active")
        if abs(prices[-1] - prices[0]) >= 0.02:
            score += 6
            notes.append("multi-snapshot momentum")

    if len(spreads) >= 3 and spreads[-1] == min(spreads):
        score += 4
        notes.append("best recent spread")

    if len(vols) >= 3:
        avg_prev = sum(vols[:-1]) / max(1, len(vols) - 1)
        if avg_prev > 0 and vols[-1] >= avg_prev * 1.2:
            score += 8
            notes.append("history shows volume pickup")

    return score, notes


def compute_signal(prev: dict[str, Any] | None, cur: Snapshot, hist_entries: list[dict[str, Any]] | None = None) -> tuple[float, list[str], str]:
    notes: list[str] = []
    score = 0.0
    bucket = classify_market(cur)
    profile = strategy_profile(bucket)
    notes.append(f"bucket={bucket}")

    if cur.liquidity >= profile["liq_good"]:
        score += 20
        notes.append("liquidity ok")
    elif cur.liquidity >= profile["liq_good"] * 0.5:
        score += 10
        notes.append("liquidity passable")
    else:
        notes.append("liquidity weak")

    if cur.volume24hr >= profile["v_good"]:
        score += 20
        notes.append("24h volume active")
    elif cur.volume24hr >= profile["v_good"] * 0.5:
        score += 10
        notes.append("24h volume decent")
    else:
        notes.append("24h volume thin")

    if cur.spread is not None:
        if cur.spread <= 0.02:
            score += 20
            notes.append("spread tight")
        elif cur.spread <= 0.05:
            score += 8
            notes.append("spread acceptable")
        else:
            score -= 10
            notes.append("spread wide")

    if cur.hours_to_end is not None:
        if profile["ideal_h_min"] <= cur.hours_to_end <= profile["ideal_h_max"]:
            score += 18
            notes.append("inside strategy window")
        elif cur.hours_to_end > profile["ideal_h_max"] * 1.5:
            score -= 14
            notes.append("too far from catalyst")
        elif cur.hours_to_end < 0:
            score -= 100
            notes.append("expired")
        else:
            score += 4
            notes.append("timing acceptable")

    if cur.yes_price is not None:
        if 0.12 <= cur.yes_price <= 0.88:
            score += 10
            notes.append("price not pinned")
        else:
            score -= 8
            notes.append("price near edge")

    score += min(abs(cur.one_hour_change) * 120, 15)
    if abs(cur.one_hour_change) >= 0.03:
        notes.append("1h move notable")

    if prev and prev.get("yes_price") is not None and cur.yes_price is not None:
        delta = cur.yes_price - float(prev["yes_price"])
        if abs(delta) >= 0.03:
            score += 15
            notes.append(f"price moved {delta:+.3f} since last scan")
        elif abs(delta) >= 0.01:
            score += 6
            notes.append(f"price drift {delta:+.3f}")

        prev_spread = prev.get("spread")
        if prev_spread is not None and cur.spread is not None and cur.spread < float(prev_spread):
            score += 5
            notes.append("spread improved")

        prev_v24 = float(prev.get("volume24hr") or 0)
        if prev_v24 > 0:
            ratio = cur.volume24hr / prev_v24
            if ratio >= 1.15:
                score += 10
                notes.append("volume acceleration")

    if hist_entries:
        hist_score, hist_notes = history_features(hist_entries, cur)
        score += hist_score
        notes.extend(hist_notes)

    return max(0.0, round(score, 2)), notes, bucket


def notify_telegram(text: str, token: str | None, chat_id: str | None) -> bool:
    if not token or not chat_id:
        return False
    data = urllib.parse.urlencode({"chat_id": chat_id, "text": text}).encode()
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    req = urllib.request.Request(url, data=data, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=20) as resp:
        return resp.status == 200


def maybe_open_paper_trade(ledger: dict[str, Any], cur: Snapshot, score: float, notes: list[str], open_threshold: float, bucket: str) -> None:
    open_positions = ledger.setdefault("open_positions", {})
    if cur.slug in open_positions:
        return
    if cur.yes_price is None or score < open_threshold:
        return
    profile = strategy_profile(bucket)
    open_positions[cur.slug] = {
        "question": cur.question,
        "bucket": bucket,
        "entry_ts": cur.ts,
        "entry_price": cur.yes_price,
        "score_at_entry": score,
        "target_price": round(min(cur.yes_price + profile["target"], 0.97), 4),
        "stop_price": round(max(cur.yes_price - profile["stop"], 0.01), 4),
        "max_hold_minutes": int(profile["hold_min"]),
        "notes": notes,
    }


def maybe_close_paper_trade(ledger: dict[str, Any], cur: Snapshot) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    open_positions = ledger.setdefault("open_positions", {})
    pos = open_positions.get(cur.slug)
    if not pos or cur.yes_price is None:
        return events
    age_min = (cur.ts - int(pos["entry_ts"])) / 60
    reason = None
    if cur.yes_price >= float(pos["target_price"]):
        reason = "target"
    elif cur.yes_price <= float(pos["stop_price"]):
        reason = "stop"
    elif age_min >= float(pos["max_hold_minutes"]):
        reason = "time"
    if not reason:
        return events
    pnl = cur.yes_price - float(pos["entry_price"])
    closed = {
        "slug": cur.slug,
        "question": cur.question,
        "entry_ts": pos["entry_ts"],
        "exit_ts": cur.ts,
        "entry_price": pos["entry_price"],
        "exit_price": cur.yes_price,
        "pnl": round(pnl, 4),
        "reason": reason,
    }
    ledger.setdefault("closed_positions", []).append(closed)
    del open_positions[cur.slug]
    events.append(closed)
    return events


def build_alert(cur: Snapshot, score: float, notes: list[str]) -> str:
    return (
        f"Polymarket signal\n"
        f"Q: {cur.question}\n"
        f"Score: {score}\n"
        f"YES: {cur.yes_price} | Spread: {cur.spread}\n"
        f"Vol24h: {round(cur.volume24hr, 2)} | Liq: {round(cur.liquidity, 2)}\n"
        f"1h: {cur.one_hour_change:+.4f} | End(h): {round(cur.hours_to_end, 2) if cur.hours_to_end is not None else 'n/a'}\n"
        f"Why: {'; '.join(notes[:5])}\n"
        f"https://polymarket.com/event/{cur.slug}"
    )


def run_once(args: argparse.Namespace) -> int:
    state = load_json(Path(args.state), {"markets": {}, "alerts": {}})
    ledger = load_json(Path(args.ledger), {"open_positions": {}, "closed_positions": []})
    history = load_json(Path(args.history), {})
    watchlist = load_watchlist(Path(args.watchlist)) if args.watchlist else None
    markets = fetch_markets(args.limit)
    now_ts = int(time.time())

    alerts = []
    paper_events = []
    next_state = {"markets": {}, "alerts": state.get("alerts", {})}

    for m in markets:
        cur = make_snapshot(m, now_ts)
        hist_entries = update_history(history, cur)
        prev = state.get("markets", {}).get(cur.slug)
        score, notes, bucket = compute_signal(prev, cur, hist_entries)

        watch_ok = True
        watch_reasons: list[str] = []
        if watchlist:
            watch_ok, watch_reasons = passes_watchlist(cur, watchlist)
            if not watch_ok:
                score = 0.0
                notes = notes + watch_reasons

        next_state["markets"][cur.slug] = asdict(cur)
        next_state["markets"][cur.slug]["signal_score"] = score
        next_state["markets"][cur.slug]["signal_notes"] = notes
        next_state["markets"][cur.slug]["bucket"] = bucket
        next_state["markets"][cur.slug]["watchlist_pass"] = watch_ok

        if watch_ok and score >= args.alert_threshold:
            last_alert = int(state.get("alerts", {}).get(cur.slug, 0))
            cooldown_ok = now_ts - last_alert >= args.cooldown_minutes * 60
            if cooldown_ok:
                alerts.append(build_alert(cur, score, notes))
                next_state.setdefault("alerts", {})[cur.slug] = now_ts

        if watch_ok:
            maybe_open_paper_trade(ledger, cur, score, notes, args.paper_open_threshold, bucket)
            paper_events.extend(maybe_close_paper_trade(ledger, cur))

    save_json(Path(args.state), next_state)
    save_json(Path(args.ledger), ledger)
    save_json(Path(args.history), history)

    if args.telegram and alerts:
        token = os.environ.get("TELEGRAM_BOT_TOKEN")
        chat_id = os.environ.get("TELEGRAM_CHAT_ID")
        for alert in alerts[: args.max_alerts_per_run]:
            notify_telegram(alert, token, chat_id)

    summary = {
        "ts": now_ts,
        "alerts": len(alerts),
        "open_positions": len(ledger.get("open_positions", {})),
        "closed_positions": len(ledger.get("closed_positions", [])),
        "paper_events": paper_events,
        "top_signals": sorted(
            [v for v in next_state["markets"].values() if v.get("signal_score", 0) >= args.min_score],
            key=lambda x: x.get("signal_score", 0),
            reverse=True,
        )[: args.top],
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Continuous Polymarket monitor")
    p.add_argument("--limit", type=int, default=150)
    p.add_argument("--top", type=int, default=10)
    p.add_argument("--min-score", type=float, default=35.0)
    p.add_argument("--alert-threshold", type=float, default=55.0)
    p.add_argument("--paper-open-threshold", type=float, default=65.0)
    p.add_argument("--cooldown-minutes", type=int, default=60)
    p.add_argument("--max-alerts-per-run", type=int, default=5)
    p.add_argument("--state", default=str(DEFAULT_STATE))
    p.add_argument("--ledger", default=str(DEFAULT_LEDGER))
    p.add_argument("--history", default=str(DEFAULT_HISTORY))
    p.add_argument("--watchlist", default=str(WATCHLIST_PATH), help="Watchlist JSON file")
    p.add_argument("--telegram", action="store_true", help="Send alerts via Telegram bot env vars")
    return p


if __name__ == "__main__":
    raise SystemExit(run_once(build_parser().parse_args()))
