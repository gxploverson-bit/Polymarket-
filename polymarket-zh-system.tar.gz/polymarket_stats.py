#!/usr/bin/env python3
"""Paper-trading performance stats for the Polymarket monitor."""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

DEFAULT_LEDGER = Path("state/polymarket-paper-ledger.json")


def load_json(path: Path) -> Any:
    if not path.exists():
        return {"open_positions": {}, "closed_positions": []}
    return json.loads(path.read_text(encoding="utf-8"))


def classify(question: str) -> str:
    q = question.lower()
    if any(k in q for k in ["bitcoin", "ethereum", "solana", "crypto", "token", "etf"]):
        return "crypto"
    if any(k in q for k in ["trump", "election", "senate", "fed", "tariff", "president", "cpi", "inflation"]):
        return "macro-politics"
    if any(k in q for k in ["openai", "gpt", "ai", "hardware"]):
        return "ai-tech"
    if any(k in q for k in ["ukraine", "china", "taiwan", "ceasefire", "war"]):
        return "geopolitics"
    return "other"


def drawdown(equity_curve: list[float]) -> float:
    peak = float("-inf")
    max_dd = 0.0
    for x in equity_curve:
        peak = max(peak, x)
        max_dd = min(max_dd, x - peak)
    return max_dd


def summarize(closed_positions: list[dict[str, Any]]) -> dict[str, Any]:
    count = len(closed_positions)
    if count == 0:
        return {
            "trades": 0,
            "wins": 0,
            "losses": 0,
            "win_rate": 0,
            "total_pnl": 0,
            "avg_pnl": 0,
            "max_drawdown": 0,
            "by_reason": {},
            "by_bucket": {},
        }

    wins = [p for p in closed_positions if p.get("pnl", 0) > 0]
    losses = [p for p in closed_positions if p.get("pnl", 0) <= 0]
    total_pnl = round(sum(float(p.get("pnl", 0)) for p in closed_positions), 4)
    avg_pnl = round(total_pnl / count, 4)
    eq = []
    running = 0.0
    for p in closed_positions:
        running += float(p.get("pnl", 0))
        eq.append(round(running, 4))

    by_reason = Counter(p.get("reason", "unknown") for p in closed_positions)
    buckets = defaultdict(list)
    for p in closed_positions:
        buckets[classify(p.get("question", ""))].append(float(p.get("pnl", 0)))
    by_bucket = {
        k: {
            "trades": len(v),
            "total_pnl": round(sum(v), 4),
            "avg_pnl": round(sum(v) / len(v), 4),
            "win_rate": round(sum(1 for x in v if x > 0) / len(v), 4),
        }
        for k, v in buckets.items()
    }

    return {
        "trades": count,
        "wins": len(wins),
        "losses": len(losses),
        "win_rate": round(len(wins) / count, 4),
        "total_pnl": total_pnl,
        "avg_pnl": avg_pnl,
        "max_drawdown": round(drawdown(eq), 4),
        "by_reason": dict(by_reason),
        "by_bucket": by_bucket,
    }


def main() -> int:
    p = argparse.ArgumentParser(description="Summarize Polymarket paper-trading results")
    p.add_argument("--ledger", default=str(DEFAULT_LEDGER))
    p.add_argument("--json", action="store_true")
    args = p.parse_args()

    ledger = load_json(Path(args.ledger))
    summary = summarize(ledger.get("closed_positions", []))
    summary["open_positions"] = len(ledger.get("open_positions", {}))

    if args.json:
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    else:
        print("# Polymarket paper-trading stats")
        print(f"trades: {summary['trades']}")
        print(f"open_positions: {summary['open_positions']}")
        print(f"wins/losses: {summary['wins']}/{summary['losses']}")
        print(f"win_rate: {summary['win_rate']}")
        print(f"total_pnl: {summary['total_pnl']}")
        print(f"avg_pnl: {summary['avg_pnl']}")
        print(f"max_drawdown: {summary['max_drawdown']}")
        print("by_reason:")
        for k, v in summary["by_reason"].items():
            print(f"  - {k}: {v}")
        print("by_bucket:")
        for k, v in summary["by_bucket"].items():
            print(f"  - {k}: trades={v['trades']} total_pnl={v['total_pnl']} avg_pnl={v['avg_pnl']} win_rate={v['win_rate']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
